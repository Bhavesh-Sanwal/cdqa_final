# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np

def clean_pred(prediction,best_paras):
    best_prediction = prediction[0]['title']
    new_list = []

    for i in range(len(prediction)): 
      if(prediction[i]['title'] == best_prediction):
          new_list.append(prediction[i])
    
    new_list=new_list[:3]

    
    ###Getting best_paras from best title
    #for i in df.iterrows():
    # if i[1]['title']==best_prediction:
    #  best_paras=i[1]['paragraphs']


    ##Formating the paras (for cut strings)
    try:
        
        for k in range(0,len(best_paras)-1):
            if(best_paras[k].endswith(".")):
                continue
            else:
                i=1
                while not(best_paras[k].endswith(".")):
                    best_paras[k]=best_paras[k]+" "+best_paras[k+i]
                    best_paras[k+i]="."
                    i=i+1
    except:
        pass

    #best_paras=[string.strip() for string in best_paras if (string != "" and string != " ") ]
    
     
    ## Appending the cut paras with full paras from formatted text
    all_paras = []  
    for j in range(len(new_list)):
      # limit=len(new_list[j]['paragraph'])
      if(new_list[j]['paragraph'].endswith(".")):  
        all_paras.append(new_list[j]['paragraph'])  
      else:  
        for i in range(len(best_paras)):  
          if(new_list[j]['paragraph'] in best_paras[i]):  
            all_paras.append(best_paras[i])


    ## removing duplicates
    temp_dup = []  
    for i in range(len(all_paras)):  
       if(all_paras[i] not in temp_dup):  
         temp_dup.append(all_paras[i])
    
    return temp_dup
    #return all_paras


