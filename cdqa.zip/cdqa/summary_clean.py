# -*- coding: utf-8 -*-
import pandas as pd
from heapq import nlargest 
from sklearn.metrics.pairwise import cosine_similarity
import networkx as nx
import re
from collections import Counter
import math

#para_summary=clean_pred(prediction,df)
def get_cosine(vec1, vec2):
    intersection = set(vec1.keys()) & set(vec2.keys())
    numerator = sum([vec1[x] * vec2[x] for x in intersection])

    sum1 = sum([vec1[x]**2 for x in vec1.keys()])
    sum2 = sum([vec2[x]**2 for x in vec2.keys()])
    denominator = math.sqrt(sum1) * math.sqrt(sum2)

    if not denominator:
        return 0.0
    else:
        return float(numerator) / denominator


def text_to_vector(text):
    word = re.compile(r'\w+')
    words = word.findall(text)
    return Counter(words)


def get_result(content_a, content_b):
    text1 = content_a
    text2 = content_b

    vector1 = text_to_vector(text1)
    vector2 = text_to_vector(text2)

    cosine_result = get_cosine(vector1, vector2)
    return cosine_result

def trimmed_para(para_summary,pred):
    trimmed_para = []  
    sh_index = 0  
    #para_split=para_summary[0].split(". ")
	
    para_split = re.split("\.\s{1}(?=\u2028|[A-Z])", para_summary[0])
    
    for index,value in enumerate(para_split):  
      if(pred.get('text') in para_split[index]):  
        sh_index = index  
    
    if(len(para_split) <=5):  
      trimmed_para = ['. '.join(para_split)]
    elif(len(para_split) >5 and sh_index <=2):  
      trimmed_para = ['. '.join(para_split[:5])]
    elif(len(para_split) >5 and sh_index >= len(para_split)-3):
      trimmed_para = ['. '.join(para_split[-5:])]
     
    else:  
      trimmed_para.append(para_split[sh_index-2]+". ")  
      trimmed_para.append(para_split[sh_index-1]+". ")  
      trimmed_para.append(para_split[sh_index]+". ")  
      trimmed_para.append(para_split[sh_index+1]+". ")  
      trimmed_para.append(para_split[sh_index+2]+".")
    return trimmed_para

def trimmed_summary(para_summary,trimmed_para):
    final_summary = ""  
    if(len(para_summary) == 1):  
      final_summary = ' '.join(trimmed_para)  
    else:  
      temp_str = ' '.join(para_summary[1:])  
      if(len(re.split("\.\s{1}(?=\u2028|[A-Z])", temp_str)) <= 4):  
        final_summary = ' '.join(trimmed_para)+". ".join(re.split("\.\s{1}(?=\u2028|[A-Z])", temp_str)[:len(re.split("\.\s{1}(?=\u2028|[A-Z])", temp_str))])  
      else:  
        final_summary = ' '.join(trimmed_para)+". ".join(re.split("\.\s{1}(?=\u2028|[A-Z])", temp_str)[:4])
    return final_summary

def extractive_summary(para_summary, query):
    cosine_sim={}
    full_para=' '.join(para_summary)
    for sentence in (re.split("\.\s{1}(?=\u2028|[A-Z])", full_para)):
      cosine_sim[sentence]=get_result(sentence,query)

    high_cosine=nlargest(5, cosine_sim, key = cosine_sim.get) 

    values=[]
    for val in high_cosine: 
      values.append(val+".")

    return values
